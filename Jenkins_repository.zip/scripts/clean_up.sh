#!/bin/bash

rm -f /var/www/my-nodejs-app/package-lock.json